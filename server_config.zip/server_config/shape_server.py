# -*- coding: UTF-8 -*-

import socket
import threading
import time

CLIENT_ADDR = '223.3.91.122'
CLIENT_PORT = 35070


def log(log_info):
    print('[' + time.asctime(time.localtime(time.time())) + ']----' + log_info)


def get_auth():
    file = '/var/lib/obfs4_usr/obfs4_bridgeline.txt'
    out = open(file, encoding='utf-8')
    lines = out.readlines()
    cert = lines[-1].split(' ')[-2]
    iat_mode = lines[-1].split(' ')[-1]
    auth = cert + ';' + iat_mode[:-1]
    return auth


def handle_connection(cs):
    port = int(str(cs.recv(128), encoding='utf-8'))
    server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
    server_sock.connect(('0.0.0.0', port))

    cs.sendall(b'server connect ok.')
    th_recv = threading.Thread(target=handle_recv, args=(cs, server_sock))
    th_recv.start()

    data = cs.recv(4096)
    while data:
        server_sock.sendall(data)
        data = cs.recv(4096)

    log('connection ending.')


def handle_recv(cs, s):
    data = s.recv(4096)
    while data:
        cs.sendall(data)
        data = s.recv(4096)

    log('connection ending.')


if __name__ == '__main__':
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((CLIENT_ADDR, CLIENT_PORT))

    mess = get_auth().encode()
    s.sendall(mess)
    s.close()

    ls = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ls.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    ls.bind(('0.0.0.0', 5500))
    log('Listening on port 5500... ')
    ls.listen(500)
    while True:
        clientSock, address = ls.accept()
        log('connect ok.')
        thread = threading.Thread(target=handle_connection, args=(clientSock, ))
        thread.start()