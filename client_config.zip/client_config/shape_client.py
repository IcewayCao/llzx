﻿# coding: utf-8

import socks
import socket
import time
import threading


IsNeedAuth = False
Username = 'admin'
Password = '123456'

SERVER_ADDR = '223.3.93.231'
SERVER_PORT = 2222

OBFS_USRNAME = ''


def log(log_info):
    print('[' + time.asctime(time.localtime(time.time())) + ']----' + log_info)


def proxy(sock):
    cs = sock
    dsp_port = 0
    dsp_addr = ''
    try:
        recv = cs.recv(512)
        VER = recv[0:1]
        # MethodNum=ord(recv[1:2])
        # Methods=[]
        # for i in range(0,MethodNum):
        # Methods.append(ord(recv[2+i:3+i]))
        if (IsNeedAuth):  # Need AUTHENICATION
            cs.send(b'\x05\x02')  # Reply
            recv = cs.recv(1024)
            Ver = recv[0:1]
            UserLen = ord(recv[1:2])
            User = recv[2:2 + UserLen]
            PassLen = ord(recv[2 + UserLen:3 + UserLen])
            Pass = recv[3 + UserLen:3 + UserLen + PassLen]
            if (User == Username and Pass == Password):
                cs.send(Ver + '\x00')
            else:
                cs.send(Ver + '\xff')
                cs.close()
                return
        else:
            cs.send(VER + b'\x00')  # NO AUTHENICATION REQUEST
        try:
            recv = cs.recv(1024)
        except Exception as ex:
            print('Client is Closed')
            return
        CMD = ord(recv[1:2])
        ATYP = ord(recv[3:4])
        if (CMD == 0x01):  # CONNECT CMD
            if (ATYP == 0x03):  # DOMAINNAME
                AddrLen = ord(recv[4:5])
                dsp_port = 256 * ord(recv[5 + AddrLen:5 + AddrLen + 1]) + ord(recv[1 + 5 + AddrLen:5 + AddrLen + 2])
                dsp_addr = socket.gethostbyname(recv[5:5 + AddrLen])
            elif (ATYP == 0x01):  # IPV4
                if (recv.count(b'.') == 4):  # Asiic  format  split by  '.'
                    AddrLen = ord(recv[4:5])
                    dsp_addr = recv[5:5 + AddrLen]
                    dsp_port = 256 * ord(recv[5 + AddrLen:5 + AddrLen + 1]) + ord(recv[5 + AddrLen + 1:5 + AddrLen + 2])
                else:  # four hex number format
                    dsp_addr = recv[4:8]
                    dsp_addrr = ''
                    for i in dsp_addr:
                        dsp_addrr += str(i) + '.'
                    dsp_addr = dsp_addrr[:-1]
                    dsp_port = 256 * ord(recv[4 + 4:4 + 4 + 1]) + ord(recv[4 + 4 + 1:4 + 4 + 2])
            else:
                print("IPV6 is not support")
                return
            cs.send(VER + b'\x00\x00\x01\x00\x00\x00\x00\x00\x00')  # REPLY
            s = auth_socks(dsp_port)
            handle_connection(cs, s)
        else:
            print("Don't support  this Cmd", CMD)
    except Exception as e:
        print(e)


def auth_socks(port):
    SOCKS5_PROXY_HOST = '127.0.0.1'  # socks 代理IP地址
    SOCKS5_PROXY_PORT = 35090  # socks 代理本地端口
    global OBFS_USRNAME
    SOCKS5_PROXY_USERNAME = OBFS_USRNAME[:-1]
    SOCKS5_PROXY_PASSWD = OBFS_USRNAME[-1]
    socks.set_default_proxy(socks.SOCKS5, SOCKS5_PROXY_HOST, SOCKS5_PROXY_PORT, username=SOCKS5_PROXY_USERNAME, password=SOCKS5_PROXY_PASSWD)
    socket.socket = socks.socksocket
    obfs_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    obfs_sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
    obfs_sock.connect((SERVER_ADDR, SERVER_PORT))
    
    obfs_sock.sendall(str(port).encode())
    log(str(obfs_sock.recv(128), encoding='utf-8'))
    return obfs_sock


def handle_connection(cs, s):
    thread = threading.Thread(target=handle_recv, args=(cs, s))
    thread.start()
    log('thread create ok')

    data = cs.recv(4096)
    while data:
        s.sendall(data)
        data = cs.recv(4096)

    log('connection ending.')


def handle_recv(cs, s):
    data = s.recv(4096)
    while data:
        cs.sendall(data)
        data = s.recv(4096)

    log('connection ending.')


def flow_recv():
    cs = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    cs.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    cs.bind(('0.0.0.0', 35080))
    log('Listening on port 35080...')
    cs.listen(500)

    while True:
        clientSock, address = cs.accept()
        log('connect ok.')
        thread = threading.Thread(target=proxy, args=(clientSock, ))
        thread.start()


if __name__ == "__main__":
    ls = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ls.bind(('0.0.0.0', 35070))
    log('Listening on port 35070... ')
    ls.listen(500)

    cs, address = ls.accept()
    recv_str = str(cs.recv(128), encoding='utf-8')
    global OBFS_USRNAME
    OBFS_USRNAME = recv_str
    print(OBFS_USRNAME)
    cs.close()
    flow_recv()
